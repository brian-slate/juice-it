# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.0.7](https://github.com/brian-slate/juice-it/compare/v1.0.6...v1.0.7) (2024-07-23)

### [1.0.6](https://github.com/brian-slate/juice-it/compare/v1.0.5...v1.0.6) (2024-07-23)

### [1.0.5](https://github.com/brian-slate/juice-it/compare/v1.0.4...v1.0.5) (2024-07-23)

### [1.0.4](https://github.com/brian-slate/juice-it/compare/v1.0.3...v1.0.4) (2024-07-23)

### [1.0.3](https://github.com/brian-slate/juice-it/compare/v1.0.2...v1.0.3) (2024-07-23)

### [1.0.2](https://github.com/brian-slate/juice-it/compare/v1.0.1...v1.0.2) (2024-07-23)

### 1.0.1 (2024-07-23)
